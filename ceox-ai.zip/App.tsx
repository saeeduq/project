import React, { useState } from 'react';
import { HashRouter, Routes, Route, Link, useLocation } from 'react-router-dom';
import RecommendationEngine from './components/RecommendationEngine';
import DynamicPricing from './components/DynamicPricing';
import BusinessDiagnostics from './components/BusinessDiagnostics';
import { ShoppingCart, BarChart2, TrendingUp, Zap, Menu, X, ArrowRight } from 'lucide-react';

const Logo: React.FC = () => (
  <div className="flex items-center gap-3">
    {/* Using the user provided image URL for the logo */}
    <img 
      src="https://pbs.twimg.com/media/Gja-XGXXoAAc4yq?format=jpg&name=large" 
      alt="CEOx AI Logo" 
      className="h-12 w-auto object-contain" 
    />
    <span className="text-2xl font-black bg-gradient-to-r from-blue-700 to-purple-700 bg-clip-text text-transparent hidden sm:block">
      CEOx AI
    </span>
  </div>
);

const NavItem: React.FC<{ to: string; icon: React.ReactNode; label: string; active?: boolean }> = ({ to, icon, label, active }) => (
  <Link
    to={to}
    className={`flex items-center gap-2 px-4 py-2 rounded-xl transition-all duration-200 font-bold ${
      active 
        ? 'bg-gradient-to-r from-blue-600 to-purple-600 text-white shadow-md' 
        : 'text-gray-600 hover:bg-gray-100 hover:text-blue-600'
    }`}
  >
    {icon}
    <span>{label}</span>
  </Link>
);

const LandingPage: React.FC = () => (
  <div className="relative overflow-hidden">
    {/* Background Shapes */}
    <div className="absolute top-0 right-0 -mr-20 -mt-20 w-96 h-96 bg-blue-100 rounded-full blur-3xl opacity-50 z-0"></div>
    <div className="absolute bottom-0 left-0 -ml-20 -mb-20 w-96 h-96 bg-purple-100 rounded-full blur-3xl opacity-50 z-0"></div>

    <div className="container mx-auto px-6 pt-12 pb-20 relative z-10">
      <div className="text-center max-w-4xl mx-auto mt-10">
        <h1 className="text-5xl md:text-7xl font-black text-gray-900 mb-6 leading-tight">
          رئيسك التنفيذي <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-purple-600">الآلي</span>
          <br /> للتجارة الإلكترونية
        </h1>
        <p className="text-xl text-gray-600 mb-10 leading-relaxed max-w-2xl mx-auto">
          منصة CEOx AI تقدم لك تحليلات متقدمة، تسعير نفسي ذكي، وتوصيات منتجات رابحة لتضاعف مبيعاتك وأرباحك بدقة الذكاء الاصطناعي.
        </p>
        
        <div className="flex flex-col sm:flex-row justify-center gap-4">
          <Link to="/diagnostics" className="px-8 py-4 bg-gradient-to-r from-blue-600 to-purple-600 text-white font-bold rounded-2xl shadow-lg hover:shadow-2xl hover:-translate-y-1 transition transform flex items-center justify-center gap-2">
            ابدأ التشخيص المجاني <ArrowRight className="w-5 h-5" />
          </Link>
          <Link to="/recommendations" className="px-8 py-4 bg-white text-gray-800 border border-gray-200 font-bold rounded-2xl hover:bg-gray-50 transition flex items-center justify-center">
            استكشف الخدمات
          </Link>
        </div>
      </div>

      {/* Features Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-24">
        <div className="bg-white p-8 rounded-3xl shadow-xl border border-gray-50 hover:border-purple-100 transition duration-300 group">
          <div className="w-14 h-14 bg-purple-100 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition">
            <Zap className="w-7 h-7 text-purple-600" />
          </div>
          <h3 className="text-2xl font-bold text-gray-800 mb-3">محرك التوصيات</h3>
          <p className="text-gray-600">اكتشف المنتجات التي يريدها عملاؤك قبل أن يطلبوها باستخدام خوارزميات التنبؤ المتقدمة.</p>
        </div>
        <div className="bg-white p-8 rounded-3xl shadow-xl border border-gray-50 hover:border-blue-100 transition duration-300 group">
          <div className="w-14 h-14 bg-blue-100 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition">
            <TrendingUp className="w-7 h-7 text-blue-600" />
          </div>
          <h3 className="text-2xl font-bold text-gray-800 mb-3">التسعير النفسي</h3>
          <p className="text-gray-600">حدد السعر المثالي الذي يحفز الشراء ويعظم الربح بناءً على علم النفس السلوكي.</p>
        </div>
        <div className="bg-white p-8 rounded-3xl shadow-xl border border-gray-50 hover:border-indigo-100 transition duration-300 group">
          <div className="w-14 h-14 bg-indigo-100 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition">
            <BarChart2 className="w-7 h-7 text-indigo-600" />
          </div>
          <h3 className="text-2xl font-bold text-gray-800 mb-3">تشخيص الأعمال</h3>
          <p className="text-gray-600">احصل على تقرير صحي شامل لمتجرك مع خطوات عملية لإصلاح المشاكل وزيادة النمو.</p>
        </div>
      </div>
    </div>
  </div>
);

const AppContent: React.FC = () => {
  const location = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans">
      {/* Navbar */}
      <nav className="sticky top-0 z-50 bg-white/80 backdrop-blur-lg border-b border-gray-100">
        <div className="container mx-auto px-6 py-4">
          <div className="flex justify-between items-center">
            <Link to="/">
                <Logo />
            </Link>

            {/* Desktop Nav */}
            <div className="hidden md:flex items-center gap-2">
              <NavItem to="/recommendations" icon={<Zap size={18} />} label="التوصيات" active={location.pathname === '/recommendations'} />
              <NavItem to="/pricing" icon={<TrendingUp size={18} />} label="التسعير" active={location.pathname === '/pricing'} />
              <NavItem to="/diagnostics" icon={<BarChart2 size={18} />} label="التشخيص" active={location.pathname === '/diagnostics'} />
            </div>

            {/* Mobile Menu Button */}
            <button className="md:hidden text-gray-600" onClick={() => setMobileMenuOpen(!mobileMenuOpen)}>
              {mobileMenuOpen ? <X /> : <Menu />}
            </button>
          </div>
        </div>

        {/* Mobile Nav */}
        {mobileMenuOpen && (
          <div className="md:hidden bg-white border-t border-gray-100 p-4 space-y-2 shadow-lg absolute w-full">
            <Link to="/recommendations" className="block px-4 py-3 rounded-lg hover:bg-gray-50" onClick={() => setMobileMenuOpen(false)}>محرك التوصيات</Link>
            <Link to="/pricing" className="block px-4 py-3 rounded-lg hover:bg-gray-50" onClick={() => setMobileMenuOpen(false)}>التسعير الديناميكي</Link>
            <Link to="/diagnostics" className="block px-4 py-3 rounded-lg hover:bg-gray-50" onClick={() => setMobileMenuOpen(false)}>تشخيص الأعمال</Link>
          </div>
        )}
      </nav>

      {/* Main Content */}
      <main className="flex-grow">
        <Routes>
          <Route path="/" element={<LandingPage />} />
          <Route path="/recommendations" element={<RecommendationEngine />} />
          <Route path="/pricing" element={<DynamicPricing />} />
          <Route path="/diagnostics" element={<BusinessDiagnostics />} />
        </Routes>
      </main>

      {/* Footer */}
      <footer className="bg-slate-900 text-white py-12 border-t border-slate-800">
        <div className="container mx-auto px-6">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="mb-6 md:mb-0 text-center md:text-right">
              <div className="flex items-center justify-center md:justify-start gap-2 mb-2">
                 <ShoppingCart className="text-blue-500" />
                 <span className="text-2xl font-bold">CEOx AI</span>
              </div>
              <p className="text-slate-400 text-sm">تمكين التجارة الإلكترونية بالذكاء الاصطناعي</p>
            </div>
            <div className="flex gap-6 text-sm text-slate-400">
              <a href="#" className="hover:text-blue-400 transition">سياسة الخصوصية</a>
              <a href="#" className="hover:text-blue-400 transition">شروط الاستخدام</a>
              <a href="#" className="hover:text-blue-400 transition">تواصل معنا</a>
            </div>
          </div>
          <div className="mt-8 text-center text-slate-600 text-xs">
            &copy; {new Date().getFullYear()} CEOx AI. جميع الحقوق محفوظة.
          </div>
        </div>
      </footer>
    </div>
  );
};

const App: React.FC = () => {
  return (
    <HashRouter>
      <AppContent />
    </HashRouter>
  );
};

export default App;