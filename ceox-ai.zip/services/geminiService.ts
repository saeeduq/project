import { GoogleGenAI, Type, Schema } from "@google/genai";
import { PricingStrategy, RecommendationItem, DiagnosisResult } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
const modelName = "gemini-3-flash-preview";

// 1. Recommendation Engine Service
export const generateRecommendations = async (
  category: string,
  targetAudience: string
): Promise<RecommendationItem[]> => {
  const schema: Schema = {
    type: Type.ARRAY,
    items: {
      type: Type.OBJECT,
      properties: {
        name: { type: Type.STRING, description: "اسم المنتج المقترح" },
        description: { type: Type.STRING, description: "وصف قصير للمنتج" },
        marketingAngle: { type: Type.STRING, description: "زاوية تسويقية جذابة" },
        confidence: { type: Type.NUMBER, description: "نسبة النجاح المتوقعة من 0 الى 100" },
      },
      required: ["name", "description", "marketingAngle", "confidence"],
    },
  };

  try {
    const response = await ai.models.generateContent({
      model: modelName,
      contents: `بصفتك خبير تجارة إلكترونية، اقترح 3 منتجات رابحة في تصنيف "${category}" تستهدف جمهور "${targetAudience}".`,
      config: {
        responseMimeType: "application/json",
        responseSchema: schema,
        systemInstruction: "أنت CEOx AI، مساعد ذكي للتجار. قدم اقتراحات مبنية على اتجاهات السوق الحالية."
      },
    });

    const text = response.text;
    if (!text) return [];
    return JSON.parse(text) as RecommendationItem[];
  } catch (error) {
    console.error("Recommendation Error:", error);
    throw error;
  }
};

// 2. Dynamic Pricing Service
export const calculateDynamicPricing = async (
  productName: string,
  cost: number,
  competitorPrice: number,
  positioning: string
): Promise<PricingStrategy> => {
  const schema: Schema = {
    type: Type.OBJECT,
    properties: {
      suggestedPrice: { type: Type.NUMBER, description: "السعر المقترح النهائي" },
      strategyName: { type: Type.STRING, description: "اسم استراتيجية التسعير (مثلاً: التسعير النفسي)" },
      psychologicalTrigger: { type: Type.STRING, description: "المحفز النفسي المستخدم (مثلاً: تأثير المرساة)" },
      explanation: { type: Type.STRING, description: "شرح لماذا تم اختيار هذا السعر" },
      competitorComparison: { type: Type.STRING, description: "مقارنة مختصرة مع المنافس" },
    },
    required: ["suggestedPrice", "strategyName", "psychologicalTrigger", "explanation", "competitorComparison"],
  };

  try {
    const response = await ai.models.generateContent({
      model: modelName,
      contents: `قم بتحليل تسعير لمنتج "${productName}". التكلفة: ${cost}. سعر المنافس: ${competitorPrice}. التموضع المطلوب: ${positioning}. استخدم علم النفس السلوكي لتحديد السعر الأمثل.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: schema,
        systemInstruction: "أنت خبير في الاقتصاد السلوكي والتسعير. هدفك تعظيم الربح مع الحفاظ على جاذبية الشراء."
      },
    });

    const text = response.text;
    if (!text) throw new Error("No response from AI");
    return JSON.parse(text) as PricingStrategy;
  } catch (error) {
    console.error("Pricing Error:", error);
    throw error;
  }
};

// 3. Business Diagnostics Service
export const diagnoseBusiness = async (
  revenue: number,
  visitors: number,
  conversionRate: number,
  adSpend: number
): Promise<DiagnosisResult> => {
  const schema: Schema = {
    type: Type.OBJECT,
    properties: {
      overallHealth: { type: Type.NUMBER, description: "صحة العمل الكلية من 100" },
      metrics: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            name: { type: Type.STRING },
            score: { type: Type.NUMBER },
            status: { type: Type.STRING, enum: ["Good", "Warning", "Critical"] },
            advice: { type: Type.STRING },
          },
          required: ["name", "score", "status", "advice"],
        },
      },
      strategicSummary: { type: Type.STRING, description: "ملخص استراتيجي شامل وخطوات تنفيذية" },
    },
    required: ["overallHealth", "metrics", "strategicSummary"],
  };

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-pro-preview", // Using Pro for deeper reasoning
      contents: `حلل أداء متجر إلكتروني بهذه الأرقام الشهرية: العائدات $${revenue}, الزوار ${visitors}, نسبة التحويل ${conversionRate}%, الإنفاق الإعلاني $${adSpend}.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: schema,
        systemInstruction: "أنت مستشار أعمال رقمي محترف. قم بتحليل الأرقام بدقة، حساب العائد على الاستثمار، وتحديد نقاط الضعف."
      },
    });

    const text = response.text;
    if (!text) throw new Error("No response from AI");
    return JSON.parse(text) as DiagnosisResult;
  } catch (error) {
    console.error("Diagnosis Error:", error);
    throw error;
  }
};