import React, { useState } from 'react';
import { DiagnosisResult } from '../types';
import { diagnoseBusiness } from '../services/geminiService';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import { Activity, AlertTriangle, CheckCircle, Loader2, TrendingUp, Users, DollarSign, MousePointer } from 'lucide-react';

const BusinessDiagnostics: React.FC = () => {
  const [revenue, setRevenue] = useState<number | ''>('');
  const [visitors, setVisitors] = useState<number | ''>('');
  const [conversion, setConversion] = useState<number | ''>('');
  const [adSpend, setAdSpend] = useState<number | ''>('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<DiagnosisResult | null>(null);

  const handleDiagnose = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!revenue || !visitors || !conversion || !adSpend) return;

    setLoading(true);
    try {
      const data = await diagnoseBusiness(Number(revenue), Number(visitors), Number(conversion), Number(adSpend));
      setResult(data);
    } catch (err) {
      console.error(err);
      alert("حدث خطأ أثناء التشخيص.");
    } finally {
      setLoading(false);
    }
  };

  const getStatusColor = (status: string) => {
      switch(status) {
          case 'Good': return '#10b981'; // emerald-500
          case 'Warning': return '#f59e0b'; // amber-500
          case 'Critical': return '#ef4444'; // red-500
          default: return '#6b7280';
      }
  };

  return (
    <div className="w-full max-w-6xl mx-auto p-6">
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 mb-8">
         {/* Sidebar Form */}
         <div className="lg:col-span-1 bg-white rounded-2xl shadow-lg p-6 h-fit">
            <h3 className="font-bold text-gray-800 mb-4 flex items-center gap-2">
                <Activity className="text-blue-600" />
                أرقام المتجر الشهرية
            </h3>
            <form onSubmit={handleDiagnose} className="space-y-4">
                <div>
                    <label className="text-xs font-bold text-gray-500 uppercase">العائدات ($)</label>
                    <div className="relative mt-1">
                        <DollarSign className="absolute left-3 top-2.5 w-4 h-4 text-gray-400" />
                        <input type="number" value={revenue} onChange={e => setRevenue(Number(e.target.value))} className="w-full pl-4 pr-10 py-2 bg-gray-50 border border-gray-200 rounded-lg focus:ring-1 focus:ring-blue-500 outline-none" placeholder="5000" required />
                    </div>
                </div>
                <div>
                    <label className="text-xs font-bold text-gray-500 uppercase">الزوار</label>
                    <div className="relative mt-1">
                        <Users className="absolute left-3 top-2.5 w-4 h-4 text-gray-400" />
                        <input type="number" value={visitors} onChange={e => setVisitors(Number(e.target.value))} className="w-full pl-4 pr-10 py-2 bg-gray-50 border border-gray-200 rounded-lg focus:ring-1 focus:ring-blue-500 outline-none" placeholder="10000" required />
                    </div>
                </div>
                <div>
                    <label className="text-xs font-bold text-gray-500 uppercase">نسبة التحويل (%)</label>
                    <div className="relative mt-1">
                        <MousePointer className="absolute left-3 top-2.5 w-4 h-4 text-gray-400" />
                        <input type="number" step="0.1" value={conversion} onChange={e => setConversion(Number(e.target.value))} className="w-full pl-4 pr-10 py-2 bg-gray-50 border border-gray-200 rounded-lg focus:ring-1 focus:ring-blue-500 outline-none" placeholder="2.5" required />
                    </div>
                </div>
                <div>
                    <label className="text-xs font-bold text-gray-500 uppercase">الصرف الإعلاني ($)</label>
                    <div className="relative mt-1">
                        <TrendingUp className="absolute left-3 top-2.5 w-4 h-4 text-gray-400" />
                        <input type="number" value={adSpend} onChange={e => setAdSpend(Number(e.target.value))} className="w-full pl-4 pr-10 py-2 bg-gray-50 border border-gray-200 rounded-lg focus:ring-1 focus:ring-blue-500 outline-none" placeholder="1000" required />
                    </div>
                </div>
                <button type="submit" disabled={loading} className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-3 rounded-xl transition flex justify-center mt-4">
                    {loading ? <Loader2 className="animate-spin" /> : "تشخيص الحالة"}
                </button>
            </form>
         </div>

         {/* Dashboard Area */}
         <div className="lg:col-span-3 space-y-6">
            {result ? (
                <>
                    {/* Health Score Header */}
                    <div className="bg-gradient-to-l from-indigo-600 to-blue-700 rounded-2xl p-6 text-white flex items-center justify-between shadow-lg">
                        <div>
                            <h2 className="text-2xl font-bold mb-1">التقرير التشخيصي الشامل</h2>
                            <p className="text-indigo-100 opacity-90">تحليل مبني على بياناتك المدخلة</p>
                        </div>
                        <div className="text-center bg-white/10 backdrop-blur rounded-xl p-4 border border-white/20">
                            <span className="block text-sm text-indigo-200">الصحة العامة</span>
                            <span className={`text-4xl font-black ${result.overallHealth > 75 ? 'text-green-300' : result.overallHealth > 50 ? 'text-yellow-300' : 'text-red-300'}`}>
                                {result.overallHealth}%
                            </span>
                        </div>
                    </div>

                    {/* Charts & Metrics */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 h-80">
                            <h4 className="font-bold text-gray-700 mb-6">مؤشرات الأداء الرئيسية</h4>
                            <ResponsiveContainer width="100%" height="80%">
                                <BarChart data={result.metrics} layout="vertical" margin={{ left: 40 }}>
                                    <CartesianGrid strokeDasharray="3 3" horizontal={false} />
                                    <XAxis type="number" domain={[0, 100]} hide />
                                    <YAxis dataKey="name" type="category" width={100} tick={{fontSize: 12, fill: '#4b5563'}} />
                                    <Tooltip 
                                        cursor={{fill: 'transparent'}}
                                        contentStyle={{borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)'}}
                                    />
                                    <Bar dataKey="score" radius={[0, 4, 4, 0]} barSize={20}>
                                        {result.metrics.map((entry, index) => (
                                            <Cell key={`cell-${index}`} fill={getStatusColor(entry.status)} />
                                        ))}
                                    </Bar>
                                </BarChart>
                            </ResponsiveContainer>
                        </div>

                        <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 h-80 overflow-y-auto custom-scrollbar">
                            <h4 className="font-bold text-gray-700 mb-4 sticky top-0 bg-white pb-2">تفاصيل المؤشرات</h4>
                            <div className="space-y-4">
                                {result.metrics.map((m, i) => (
                                    <div key={i} className="flex items-start gap-3 p-3 rounded-lg bg-gray-50">
                                        {m.status === 'Good' && <CheckCircle className="w-5 h-5 text-green-500 shrink-0 mt-0.5" />}
                                        {m.status === 'Warning' && <AlertTriangle className="w-5 h-5 text-amber-500 shrink-0 mt-0.5" />}
                                        {m.status === 'Critical' && <Activity className="w-5 h-5 text-red-500 shrink-0 mt-0.5" />}
                                        <div>
                                            <div className="flex justify-between items-center w-full mb-1">
                                                <span className="font-bold text-sm text-gray-800">{m.name}</span>
                                                <span className={`text-xs px-2 py-0.5 rounded-full font-bold text-white`} style={{backgroundColor: getStatusColor(m.status)}}>{m.status === 'Good' ? 'ممتاز' : m.status === 'Warning' ? 'تحذير' : 'خطر'}</span>
                                            </div>
                                            <p className="text-xs text-gray-600 leading-relaxed">{m.advice}</p>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </div>
                    </div>

                    {/* Strategic Summary */}
                    <div className="bg-indigo-50 border border-indigo-100 rounded-2xl p-6">
                        <h3 className="font-bold text-indigo-900 text-lg mb-3">الخطة الاستراتيجية للرئيس التنفيذي</h3>
                        <p className="text-indigo-800 leading-loose whitespace-pre-wrap">
                            {result.strategicSummary}
                        </p>
                    </div>
                </>
            ) : (
                <div className="h-full min-h-[400px] flex flex-col items-center justify-center text-center p-8 bg-white/50 rounded-2xl border border-dashed border-gray-300">
                    <Activity className="w-16 h-16 text-gray-300 mb-4" />
                    <h3 className="text-xl font-bold text-gray-400">ابدأ التشخيص الآن</h3>
                    <p className="text-gray-400 mt-2">نحن بحاجة لبياناتك لنخبرك كيف تنمو بعملك.</p>
                </div>
            )}
         </div>
      </div>
    </div>
  );
};

export default BusinessDiagnostics;