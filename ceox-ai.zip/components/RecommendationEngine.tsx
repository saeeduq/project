import React, { useState } from 'react';
import { RecommendationItem } from '../types';
import { generateRecommendations } from '../services/geminiService';
import { Search, Sparkles, Loader2, TrendingUp, Target } from 'lucide-react';

const RecommendationEngine: React.FC = () => {
  const [category, setCategory] = useState('');
  const [audience, setAudience] = useState('');
  const [loading, setLoading] = useState(false);
  const [results, setResults] = useState<RecommendationItem[]>([]);

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!category || !audience) return;

    setLoading(true);
    try {
      const data = await generateRecommendations(category, audience);
      setResults(data);
    } catch (err) {
      console.error(err);
      alert("حدث خطأ أثناء الاتصال بالرئيس الآلي.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="w-full max-w-5xl mx-auto p-6">
      <div className="text-center mb-10">
        <h2 className="text-3xl font-bold text-gray-800 mb-2 flex items-center justify-center gap-2">
          <Sparkles className="text-brand-accent w-8 h-8" />
          محرك التوصيات المتقدم
        </h2>
        <p className="text-gray-600">اكتشف المنتجات الرابحة التالية بناءً على تحليل السوق والجمهور.</p>
      </div>

      <div className="bg-white rounded-2xl shadow-xl p-8 mb-10 border border-indigo-50">
        <form onSubmit={handleSearch} className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="relative">
            <label className="block text-sm font-medium text-gray-700 mb-2">تصنيف المتجر</label>
            <div className="relative">
              <input
                type="text"
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                placeholder="مثال: إكسسوارات الجوال"
                className="w-full pl-4 pr-10 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none transition"
              />
              <Search className="absolute left-3 top-3 text-gray-400 w-5 h-5" />
            </div>
          </div>
          
          <div className="relative">
            <label className="block text-sm font-medium text-gray-700 mb-2">الجمهور المستهدف</label>
            <div className="relative">
              <input
                type="text"
                value={audience}
                onChange={(e) => setAudience(e.target.value)}
                placeholder="مثال: شباب محب للتقنية"
                className="w-full pl-4 pr-10 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none transition"
              />
              <Target className="absolute left-3 top-3 text-gray-400 w-5 h-5" />
            </div>
          </div>

          <div className="flex items-end">
            <button
              type="submit"
              disabled={loading}
              className="w-full bg-gradient-to-r from-blue-600 to-purple-600 text-white font-bold py-3 px-6 rounded-xl hover:shadow-lg transform hover:-translate-y-1 transition duration-200 flex items-center justify-center gap-2 disabled:opacity-50"
            >
              {loading ? <Loader2 className="animate-spin" /> : "تحليل واقتراح"}
            </button>
          </div>
        </form>
      </div>

      {results.length > 0 && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {results.map((item, index) => (
            <div key={index} className="bg-white rounded-2xl shadow-lg hover:shadow-2xl transition duration-300 overflow-hidden border border-gray-100 group">
              <div className="h-40 bg-gradient-to-br from-indigo-50 to-purple-50 flex items-center justify-center relative">
                 <img 
                    src={`https://picsum.photos/400/200?random=${index}`} 
                    alt="Product Placeholder" 
                    className="w-full h-full object-cover opacity-80 group-hover:scale-105 transition duration-500"
                 />
                 <div className="absolute top-4 right-4 bg-white/90 backdrop-blur px-3 py-1 rounded-full text-xs font-bold text-indigo-600 shadow-sm">
                   نسبة نجاح {item.confidence}%
                 </div>
              </div>
              <div className="p-6">
                <h3 className="text-xl font-bold text-gray-900 mb-3">{item.name}</h3>
                <p className="text-gray-600 text-sm mb-4 leading-relaxed">{item.description}</p>
                <div className="bg-purple-50 p-4 rounded-xl">
                  <div className="flex items-center gap-2 mb-2">
                    <TrendingUp className="w-4 h-4 text-purple-600" />
                    <span className="text-xs font-bold text-purple-700 uppercase">زاوية التسويق</span>
                  </div>
                  <p className="text-sm text-purple-900 font-medium">{item.marketingAngle}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default RecommendationEngine;