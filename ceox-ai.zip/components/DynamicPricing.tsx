import React, { useState } from 'react';
import { PricingStrategy } from '../types';
import { calculateDynamicPricing } from '../services/geminiService';
import { DollarSign, Tag, Brain, Loader2, ArrowRight } from 'lucide-react';

const DynamicPricing: React.FC = () => {
  const [productName, setProductName] = useState('');
  const [cost, setCost] = useState<number | ''>('');
  const [competitorPrice, setCompetitorPrice] = useState<number | ''>('');
  const [positioning, setPositioning] = useState('Premium');
  const [loading, setLoading] = useState(false);
  const [strategy, setStrategy] = useState<PricingStrategy | null>(null);

  const handleCalculate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!productName || !cost || !competitorPrice) return;

    setLoading(true);
    try {
      const result = await calculateDynamicPricing(
        productName,
        Number(cost),
        Number(competitorPrice),
        positioning
      );
      setStrategy(result);
    } catch (err) {
      console.error(err);
      alert("تعذر حساب استراتيجية التسعير.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="w-full max-w-6xl mx-auto p-6 flex flex-col lg:flex-row gap-8">
      {/* Input Section */}
      <div className="w-full lg:w-1/3">
        <div className="bg-white rounded-2xl shadow-xl p-8 border border-indigo-50 sticky top-6">
          <div className="mb-6 flex items-center gap-3">
            <div className="p-3 bg-blue-100 rounded-full text-blue-600">
               <Tag className="w-6 h-6" />
            </div>
            <h2 className="text-xl font-bold text-gray-800">بيانات المنتج</h2>
          </div>
          
          <form onSubmit={handleCalculate} className="space-y-5">
            <div>
              <label className="block text-sm font-medium text-gray-600 mb-1">اسم المنتج</label>
              <input
                type="text"
                className="w-full px-4 py-2 rounded-lg border border-gray-200 focus:ring-2 focus:ring-blue-500 outline-none"
                value={productName}
                onChange={(e) => setProductName(e.target.value)}
                placeholder="ساعة ذكية"
                required
              />
            </div>
            
            <div className="grid grid-cols-2 gap-4">
               <div>
                <label className="block text-sm font-medium text-gray-600 mb-1">التكلفة ($)</label>
                <input
                    type="number"
                    className="w-full px-4 py-2 rounded-lg border border-gray-200 focus:ring-2 focus:ring-blue-500 outline-none"
                    value={cost}
                    onChange={(e) => setCost(Number(e.target.value))}
                    placeholder="20"
                    required
                />
               </div>
               <div>
                <label className="block text-sm font-medium text-gray-600 mb-1">المنافس ($)</label>
                <input
                    type="number"
                    className="w-full px-4 py-2 rounded-lg border border-gray-200 focus:ring-2 focus:ring-blue-500 outline-none"
                    value={competitorPrice}
                    onChange={(e) => setCompetitorPrice(Number(e.target.value))}
                    placeholder="50"
                    required
                />
               </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-600 mb-1">التموضع السوقي</label>
              <select
                className="w-full px-4 py-2 rounded-lg border border-gray-200 focus:ring-2 focus:ring-blue-500 outline-none bg-white"
                value={positioning}
                onChange={(e) => setPositioning(e.target.value)}
              >
                <option value="Economy">اقتصادي (منافسة بالسعر)</option>
                <option value="Premium">جودة عالية (بريميوم)</option>
                <option value="Luxury">فاخر (Luxury)</option>
              </select>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full mt-4 bg-gradient-to-r from-blue-600 to-purple-600 text-white font-bold py-3 rounded-xl hover:opacity-90 transition flex justify-center items-center gap-2"
            >
              {loading ? <Loader2 className="animate-spin" /> : "حساب السعر الأمثل"}
            </button>
          </form>
        </div>
      </div>

      {/* Result Section */}
      <div className="w-full lg:w-2/3">
        {strategy ? (
          <div className="bg-white rounded-2xl shadow-xl overflow-hidden border border-gray-100 h-full animate-fade-in">
            <div className="bg-gradient-to-r from-blue-900 to-indigo-900 p-10 text-white relative overflow-hidden">
                <div className="absolute top-0 right-0 w-64 h-64 bg-white opacity-5 rounded-full -translate-y-1/2 translate-x-1/4 blur-3xl"></div>
                <div className="relative z-10 flex flex-col md:flex-row justify-between items-center gap-6">
                    <div>
                        <p className="text-blue-200 font-medium mb-1">السعر النفسي المقترح</p>
                        <h1 className="text-6xl font-black tracking-tight">${strategy.suggestedPrice}</h1>
                    </div>
                    <div className="bg-white/10 backdrop-blur-md px-6 py-4 rounded-xl border border-white/20">
                        <div className="flex items-center gap-2 mb-1">
                            <Brain className="w-5 h-5 text-purple-300" />
                            <span className="font-bold text-lg">{strategy.strategyName}</span>
                        </div>
                        <p className="text-sm text-blue-100">{strategy.psychologicalTrigger}</p>
                    </div>
                </div>
            </div>
            
            <div className="p-8 space-y-8">
                <div>
                    <h3 className="text-xl font-bold text-gray-800 mb-4 flex items-center gap-2">
                        <span className="w-1 h-8 bg-blue-500 rounded-full"></span>
                        تحليل الذكاء الاصطناعي
                    </h3>
                    <p className="text-gray-600 leading-loose text-lg">
                        {strategy.explanation}
                    </p>
                </div>

                <div className="bg-gray-50 p-6 rounded-2xl border border-gray-100">
                    <h4 className="font-bold text-gray-800 mb-2">مقارنة مع المنافسين</h4>
                    <p className="text-gray-600">
                        {strategy.competitorComparison}
                    </p>
                    <div className="mt-4 flex items-center gap-4 text-sm font-medium">
                        <div className="flex items-center gap-2 text-red-500">
                            <DollarSign className="w-4 h-4" />
                            منافس: ${competitorPrice}
                        </div>
                        <ArrowRight className="text-gray-400" />
                        <div className="flex items-center gap-2 text-green-600">
                            <DollarSign className="w-4 h-4" />
                            أنت: ${strategy.suggestedPrice}
                        </div>
                    </div>
                </div>
            </div>
          </div>
        ) : (
          <div className="h-full min-h-[400px] flex flex-col items-center justify-center text-center p-8 bg-white/50 rounded-2xl border border-dashed border-gray-300">
             <div className="w-20 h-20 bg-blue-50 rounded-full flex items-center justify-center mb-4">
                 <DollarSign className="w-10 h-10 text-blue-300" />
             </div>
             <h3 className="text-xl font-bold text-gray-400">النتيجة ستظهر هنا</h3>
             <p className="text-gray-400 mt-2 max-w-sm">أدخل بيانات المنتج والتكلفة للحصول على استراتيجية تسعير نفسية متقدمة.</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default DynamicPricing;