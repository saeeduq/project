export interface RecommendationItem {
  name: string;
  description: string;
  marketingAngle: string;
  confidence: number;
}

export interface PricingStrategy {
  suggestedPrice: number;
  strategyName: string;
  psychologicalTrigger: string;
  explanation: string;
  competitorComparison: string;
}

export interface BusinessMetric {
  name: string;
  score: number;
  status: 'Good' | 'Warning' | 'Critical';
  advice: string;
}

export interface DiagnosisResult {
  overallHealth: number;
  metrics: BusinessMetric[];
  strategicSummary: string;
}

export enum ServiceType {
  RECOMMENDATION = 'RECOMMENDATION',
  PRICING = 'PRICING',
  DIAGNOSTICS = 'DIAGNOSTICS',
  HOME = 'HOME'
}